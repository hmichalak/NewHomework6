newletter <-
function(x){
  rando <- sample(letters[1:26], 1)
  return(rando)
}
